// 1. 기존 도면 변경 함수
function changeFloor(floorName, element) {
    const buttons = document.querySelectorAll('.floor-btn');
    buttons.forEach(btn => btn.classList.remove('active'));
    element.classList.add('active');

    const imageElement = document.getElementById('floor-image-display');
    const groupA = ['B3F', 'B1F', '2F', '4F'];
    const groupB = ['B2F', '1F', '3F'];

    if (groupA.includes(floorName)) {
        imageElement.src = "/static/images/floor_plan-2.jpg";
    } else if (groupB.includes(floorName)) {
        imageElement.src = "/static/images/floor_plan-1.jpg";
    }
}

// 2. 로봇 이동 제어 로직
let posX = 50; // 초기 위치 (%)
let posY = 50;
let moveInterval = null;
const speed = 1.5; // 이동 속도

function startMove(direction, element) {
    // 버튼 배경색 변경
    element.classList.add('pressing');

    // 연속 이동을 위해 Interval 설정
    if (moveInterval) clearInterval(moveInterval);
    
    moveInterval = setInterval(() => {
        const robot = document.getElementById('robot-icon');
        
        if (direction === 'up') posY -= speed;
        if (direction === 'down') posY += speed;
        if (direction === 'left') posX -= speed;
        if (direction === 'right') posX += speed;

        // 화면 밖으로 나가지 않도록 제한 (0% ~ 100%)
        posX = Math.max(5, Math.min(95, posX));
        posY = Math.max(5, Math.min(95, posY));

        robot.style.left = posX + "%";
        robot.style.top = posY + "%";
    }, 50); // 0.05초마다 위치 갱신
}

function stopMove(element) {
    // 버튼 배경색 원복
    element.classList.remove('pressing');
    // 이동 중지
    clearInterval(moveInterval);
}