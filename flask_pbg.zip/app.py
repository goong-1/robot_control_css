from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def index():
    # 버튼 노출 순서 (위에서 아래로)
    floors = ['4F', '3F', '2F', '1F', 'B1F', 'B2F', 'B3F']
    return render_template('index.html', floors=floors)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)