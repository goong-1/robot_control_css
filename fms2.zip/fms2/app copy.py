from flask import Flask, render_template, jsonify
from flask_socketio import SocketIO
import sqlite3
import random
import threading
import serial
import time

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")

# --- [1] DB 초기화 (변동 없음) ---
def init_db():
    conn = sqlite3.connect('robot_data.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS telemetry (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            temp REAL,
            speed REAL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    cursor.execute('SELECT COUNT(*) FROM telemetry')
    if cursor.fetchone()[0] == 0:
        cursor.execute('INSERT INTO telemetry (temp, speed) VALUES (?, ?)', (25.0, 0.0))
        conn.commit()
    conn.close()

init_db()

# --- [2] 아두이노 시리얼 통신 (실제 온도만 INSERT) ---
def read_serial():
    global ser
    try:
        ser = serial.Serial('/dev/ttyUSB0', 9600, timeout=1)
        print("✅ SUCCESS: Arduino Connected")
    except Exception as e:
        ser = None
        print(f"⚠️ Arduino Connection Failed: {e}")

    # 초기값 설정
    last_received_time = time.time()
    offline_sent = False # 오프라인 신호를 이미 보냈는지 체크 (중복 전송 방지)

    while True:
        try:
            # 1. 시리얼 데이터 확인
            if ser and ser.in_waiting > 0:
                line = ser.readline().decode('utf-8').strip()
                if line:
                    parts = line.split(',')
                    if len(parts) == 3:
                        temp, joyX, joyY = float(parts[0]), int(parts[1]), int(parts[2])

                        # DB 저장
                        with sqlite3.connect('robot_data.db') as conn:
                            cursor = conn.cursor()
                            cursor.execute('INSERT INTO telemetry (temp, speed) VALUES (?, ?)', (temp, 0.0))
                            conn.commit()

                        # 웹 전송
                        socketio.emit('serial_data', {
                            'temp': temp, 'joyX': joyX, 'joyY': joyY, 'status': 'Online'
                        })

                        # 수신 성공 시 시간 업데이트 및 플래그 초기화
                        print(f"📥 Received: {temp}, {joyX}, {joyY}")
                        last_received_time = time.time()
                        offline_sent = False 
                        continue # 데이터 받았으면 즉시 다음 루프로 (타임아웃 체크 건너뜀)

        except Exception as e:
            print(f"❌ Read Error: {e}")
            ser = None

        # 2. 리셋/연결 끊김 감지 (기준을 3초로 확장)
        # 마지막 수신 후 3초 경과 AND 아직 오프라인 신호를 안 보냈을 때만 실행
        if (time.time() - last_received_time > 3.0) and not offline_sent:
            print("⚠️ [TIMEOUT]: Arduino is resetting... Sending '--'")
            socketio.emit('serial_data', {
                'temp': '--', 'joyX': 512, 'joyY': 512, 'status': 'Offline'
            })
            offline_sent = True # 한 번 보냈으므로 다음 데이터 올 때까지 대기

        time.sleep(0.1)
threading.Thread(target=read_serial, daemon=True).start()

# --- [3] 웹 API (DB 조회 전용) ---
@app.route('/api/telemetry')
def get_telemetry():
    conn = sqlite3.connect('robot_data.db')
    cursor = conn.cursor()
    cursor.execute('SELECT temp FROM telemetry ORDER BY timestamp DESC LIMIT 1')
    row = cursor.fetchone()
    conn.close()

    return jsonify({
        "temp": row[0] if row else 25.0,
        "battery": random.randint(95, 96), # 상태 정보는 랜덤 유지
        "cpu": random.randint(10, 15),
        "memory": random.randint(30, 33)
    })

@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5001, debug=True)