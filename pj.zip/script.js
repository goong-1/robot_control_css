// === Zone 4: 우측 패널 차트 렌더링 ===
class Zone4Dashboard {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
    }
    generateChartBars(dataArray) {
        let barsHtml = '';
        dataArray.forEach(val => {
            const heightPct = Math.min(val, 100); 
            barsHtml += '<div class="bar" style="height: ' + heightPct + '%;"></div>';
        });
        return barsHtml;
    }
    render(data) {
        const chartHtml = this.generateChartBars(data.chartData);
        const htmlArray = [
            '<div class="dashboard-panel">',
                '<div class="panel-card">',
                    '<div class="latency-header">Latency</div>',
                    '<div class="latency-numbers">',
                        '<div class="val-blue">' + data.controlLatency + ' <span class="unit">ms</span></div>',
                        '<div class="val-green">' + data.robotLatency + ' <span class="unit">ms</span></div>',
                    '</div>',
                    '<div class="chart-container">', chartHtml, '</div>',
                    '<div class="legend"><span><span class="dot-blue"></span> 관제 레이턴시</span><span><span class="dot-green"></span> 로봇 레이턴시</span></div>',
                '</div>',
                '<div class="panel-card camera-card"><img src="camera.jpg" alt="Camera View" style="width: 100%; height: 100%; object-fit: cover;"></div>',
            '</div>'
        ];
        this.container.innerHTML = htmlArray.join('');
    }
}

// 화면이 다 로드된 후 실행
window.onload = () => {
    const dashboardData = { controlLatency: 55, robotLatency: 93, cameraState: "IDLE", chartData: [20, 35, 40, 60, 80, 50, 45, 70, 90, 85, 60, 50, 40, 30, 80, 100, 70, 65] };
    const dashboardModule = new Zone4Dashboard("zone4-app");
    dashboardModule.render(dashboardData);

    // 🌟 이 안에 DOM을 조작하는 이벤트 리스너들을 넣어주는 것이 안전합니다!

    // === Zone 5: 방향키 클릭 효과 ===
    // 전역 스코프에 함수로 빼두거나, 이벤트 위임 방식으로 처리
    const dpadButtons = document.querySelectorAll('.dpad-btn');
    dpadButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            dpadButtons.forEach(b => b.classList.remove('dpad-active'));
            this.classList.add('dpad-active');
            console.log("명령 전송됨:", this.innerText);
        });
    });

    // === Zone 5: 중앙 탭 및 버튼 이벤트 ===
    function setupClickEvents(selector) {
        const elements = document.querySelectorAll(selector);
        elements.forEach(el => {
            el.addEventListener('click', () => {
                elements.forEach(e => e.classList.remove("active"));
                el.classList.add("active");
            });
        });
    }
    setupClickEvents(".control-section .control-tab"); // 중앙 탭
    setupClickEvents(".control-section .btn");         // 중앙 버튼

    // === Zone 5: 왼쪽 로그 탭 이벤트 ===
    const logTabs = document.querySelectorAll(".log-tab");
    logTabs.forEach(tab => {
        tab.addEventListener("click", () => {
            logTabs.forEach(t => t.classList.remove("active"));
            tab.classList.add("active");
        });
    });

    // === Zone 3: 중앙 지도 3D 틸트 효과 ===
    const mapWrapper = document.querySelector('.interactive-map-wrapper');
    const mapImage = document.querySelector('.interactive-map-image');
    
    if(mapWrapper && mapImage) {
        mapWrapper.addEventListener('mousemove', (e) => {
            const rect = mapWrapper.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const rotateX = ((y - centerY) / centerY) * -15;
            const rotateY = ((x - centerX) / centerX) * 15;
            
            mapImage.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
        });

        mapWrapper.addEventListener('mouseleave', () => {
            mapImage.style.transform = `perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)`;
        });
    }
};
