from flask import Flask, jsonify, render_template, request # request 추가됨
import threading
import time
import random

from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from sqlalchemy import desc

app = Flask(__name__)

# [설정] 완식님의 MariaDB 연결
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://vboxmaster:1234@localhost/test_rdb'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# --- [DB 테이블 구조] ---
class RobotLog(db.Model):
    __tablename__ = 'robot_logs'
    id = db.Column(db.Integer, primary_key=True)
    robot_id = db.Column(db.String(50))
    x = db.Column(db.Float)
    y = db.Column(db.Float)
    direction = db.Column(db.String(20)) # 수동 제어 방향 저장을 위한 컬럼 추가
    floor = db.Column(db.String(10))
    battery = db.Column(db.Float)
    cpu = db.Column(db.Float)
    memory = db.Column(db.Float)
    latency_ctrl = db.Column(db.Integer)
    latency_robot = db.Column(db.Integer)
    status = db.Column(db.String(20))
    created_at = db.Column(db.DateTime, default=datetime.now)

# --- [로봇 시뮬레이터 (Mock)] ---
class RobotMockManager:
    def __init__(self):
        self.state = {
            "robot_id": "SEONGSU_03",
            "status": "moving",
            "x": 120.5,
            "y": 45.2,
            "floor": "B1F",
            "battery_percent": 98.0,
            "battery_voltage": 49.0,
            "cpu_usage": 2.0,
            "memory_usage": 33.0,
            "latency_total": 55,
            "latency_robot": 93
        }
        self.running = True
        self.thread = threading.Thread(target=self._update_mock_data, daemon=True)
        self.thread.start()

    def _update_mock_data(self):
        while self.running:
            time.sleep(1) 
            if self.state["status"] == "moving":
                if self.state["battery_percent"] > 0:
                    self.state["battery_percent"] -= random.uniform(0.01, 0.05)
                # 좌표 이동 시뮬레이션
                self.state["x"] += random.uniform(-0.1, 0.1)
                self.state["y"] += random.uniform(-0.1, 0.1)
            
            self.state["cpu_usage"] = round(random.uniform(1.0, 15.0), 1)
            self.state["memory_usage"] = round(random.uniform(30.0, 35.0), 1)
            self.state["latency_total"] = int(random.uniform(40, 80))
            self.state["latency_robot"] = int(random.uniform(80, 120))

    def get_state(self):
        state_copy = self.state.copy()
        state_copy["battery_percent"] = round(state_copy["battery_percent"], 1)
        return state_copy

robot_manager = RobotMockManager()

# --- [API 라우터] ---
@app.route('/')
def dashboard():
    return render_template('index.html')

@app.route('/api/robot_stats')
def get_robot_stats():
    current_state = robot_manager.get_state()

    # 1. DB에 실시간 상태 기록
    new_log = RobotLog(
        robot_id=current_state['robot_id'],
        x=current_state['x'],
        y=current_state['y'],
        floor=current_state['floor'],
        battery=current_state['battery_percent'],
        cpu=current_state['cpu_usage'],
        memory=current_state['memory_usage'],
        latency_ctrl=current_state['latency_total'],
        latency_robot=current_state['latency_robot'],
        status=current_state['status']
    )
    db.session.add(new_log)
    db.session.commit()

    return jsonify({
        "status": "success",
        "x": current_state['x'],
        "y": current_state['y'],
        "floor": current_state['floor'],
        "zone2": {
            "on_count": 14,
            "off_count": 0,
            "battery_percent": current_state['battery_percent'],
            "voltage": current_state['battery_voltage'],
            "cpu_usage": current_state['cpu_usage'],
            "memory_usage": current_state['memory_usage']
        },
        "zone4": {
            "control_latency": current_state['latency_total'],
            "robot_latency": current_state['latency_robot']
        }
    })

# 원격 제어 버튼 클릭 시 호출되는 API (SQLAlchemy 방식으로 통일)
@app.route('/update_position', methods=['POST'])
def update_position():
    data = request.get_json()
    if not data:
        return jsonify({"status": "error", "message": "데이터가 없습니다."}), 400

    # JS에서 보낸 데이터 받기
    x = data.get('x')
    y = data.get('y')
    direction = data.get('direction')

    try:
        # SQLAlchemy 모델을 사용하여 DB 저장
        new_control_log = RobotLog(
            robot_id="SEONGSU_03",
            x=float(x),
            y=float(y),
            direction=direction,
            status="manual_control", # 수동 제어 중임을 표시
            floor="B1F"
        )
        db.session.add(new_control_log)
        db.session.commit()
        
        # 실제 로봇 시뮬레이터의 위치도 동기화 (버튼 누른 위치로 로봇 이동)
        robot_manager.state["x"] = float(x)
        robot_manager.state["y"] = float(y)
        
        return jsonify({"status": "success"})
    except Exception as e:
        db.session.rollback() # 에러 발생 시 되돌리기
        print(f"Update Position Error: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

if __name__ == '__main__':
    with app.app_context():
        # 테이블이 없으면 생성 (direction 컬럼 포함)
        db.create_all()
    app.run(host='0.0.0.0', port=5000, debug=True, use_reloader=False)