// === Zone 4: 우측 패널 차트 및 웹캠 렌더링 클래스 ===
class Zone4Dashboard {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
    }

    generateChartBars(dataArray) {
        let barsHtml = '';
        dataArray.forEach(val => {
            const heightPct = Math.min(val, 100); 
            barsHtml += `<div class="bar" style="height: ${heightPct}%;"></div>`;
        });
        return barsHtml;
    }

    render(data) {
        if (!this.container) return;
        const chartHtml = this.generateChartBars(data.chartData);
        const html = `
            <div class="dashboard-panel">
                <div class="panel-card">
                    <div class="latency-header">Latency</div>
                    <div class="latency-numbeimage_4206dbrs">
                        <div class="val-blue">${data.controlLatency} <span class="unit">ms</span></div>
                        <div class="val-green">${data.robotLatency} <span class="unit">ms</span></div>
                    </div>
                    <div class="chart-container" id="realtime-chart">${chartHtml}</div>
                    <div class="legend">
                        <span><span class="dot-blue"></span> 관제 레이턴시</span>
                        <span><span class="dot-green"></span> 로봇 레이턴시</span>
                    </div>
                </div>
                <div class="panel-card camera-card" id="camera-container">
                    <video id="webcam" autoplay playsinline style="width: 100%; height: 100%; object-fit: cover; background: #000;"></video>
                </div>
            </div>`;
        this.container.innerHTML = html;
    }
}

// === 공통: 클릭 이벤트 설정 함수 ===
function setupClickEvents(selector) {
    const elements = document.querySelectorAll(selector);
    elements.forEach(el => {
        el.addEventListener('click', () => {
            elements.forEach(e => e.classList.remove("active", "dpad-active"));
            el.classList.add(selector.includes('dpad') ? "dpad-active" : "active");
        });
    });
}

// === 웹캠 시작 함수 ===
async function startWebcam() {
    const videoElement = document.getElementById('webcam');
    if (!videoElement) return;

    try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
            video: true, 
            audio: false 
        });
        videoElement.srcObject = stream;
    } catch (error) {
        console.error("Webcam Error:", error);
        const container = document.getElementById('camera-container');
        if (container) {
            container.innerHTML = '<div style="color:#666; font-size:12px; display:flex; justify-content:center; align-items:center; height:100%; width:100%; background:#222;">카메라 연결 권한이 필요합니다.</div>';
        }
    }
}

// === 전역 데이터 관리 (차트 애니메이션용) ===
let currentChartData = [20, 35, 40, 60, 80, 50, 45, 70, 90, 85, 60, 50, 40, 30, 80, 100, 70, 65];

// === 실시간 데이터 업데이트 함수 (DB 연동) ===
async function updateDashboard(dashboardInstance) {
    try {
        const response = await fetch('/api/robot_stats');
        const data = await response.json();

        // 1. 배너 속도 업데이트 (0.95 m/s)
        const speedElement = document.querySelector('.banner-speed');
        if (speedElement) speedElement.innerHTML = `${data.speed} <span>m/s</span>`;

        // 2. 엘리베이터 및 층수 업데이트
        const infoValues = document.querySelectorAll('.banner-info .info-value');
        if (infoValues.length >= 2) {
            infoValues[0].innerText = data.elevator;
            infoValues[1].innerText = data.floor;
        }

        // 3. 지도 위 로봇 아이콘 위치 업데이트
        const robotMarker = document.getElementById('robot-marker');
        if (robotMarker) {
            robotMarker.style.left = data.x + "%";
            robotMarker.style.top = data.y + "%";
        }

        // 4. (추가) 우측 패널 차트에 실시간 속도 반영
        currentChartData.push(data.speed * 50); // 속도값을 차트 높이로 변환(보정)
        currentChartData.shift();
        const chartContainer = document.getElementById('realtime-chart');
        if (chartContainer) {
            chartContainer.innerHTML = dashboardInstance.generateChartBars(currentChartData);
        }

        

        // updateDashboard 함수 내부에 추가
        // 5. 상단 상태 박스(Zone 2) 업데이트
        const statusBoxes = document.querySelectorAll('.zone-2 .status-box strong');
        if (statusBoxes.length >= 6) {
            statusBoxes[2].innerText = `${data.zone2.battery_percent} % ⚡`;
            statusBoxes[3].innerText = `${data.zone2.voltage} V`;
            statusBoxes[4].innerText = `${data.zone2.cpu_usage} %`;
            statusBoxes[5].innerText = `${data.zone2.memory_usage} %`;
        }


    } catch (err) {
        console.error("DB 데이터 동기화 실패:", err);
    }
}

// === 메인 실행부 ===
window.onload = () => {
    // 1. 대시보드 초기 렌더링
    const initialData = { 
        controlLatency: 55, 
        robotLatency: 93, 
        cameraState: "IDLE", 
        chartData: currentChartData 
    };
    const dashboardModule = new Zone4Dashboard("zone4-app");
    dashboardModule.render(initialData);

    // 2. 웹캠 및 실시간 루프 시작
    startWebcam();
    setInterval(() => updateDashboard(dashboardModule), 1000);

    // 3. 이벤트 리스너 등록
    setupClickEvents(".dpad-btn");
    setupClickEvents(".control-tab");
    setupClickEvents(".control-section .btn");
    setupClickEvents(".log-tab");
    setupClickEvents(".upgraded-panel .tab");


};