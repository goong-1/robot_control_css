from flask import Flask, render_template, request, jsonify
import pymysql

app = Flask(__name__)

# --- [설정] MySQL 연결 정보 (사용자 환경에 맞게 수정 필수) ---
db_config = {
    'host': 'localhost',
    'user': 'root',         # MySQL 사용자명 (예: root)
    'password': 'pbg', # MySQL 비밀번호
    'db': 'test_db',       # 미리 생성한 데이터베이스 이름
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

# --- [메인 페이지] ---
@app.route('/')
def index():
    """메인 관제 페이지를 렌더링합니다."""
    return render_template('index.html')

# --- [API] 로봇 위치 업데이트 및 DB 저장 ---
@app.route('/update_position', methods=['POST'])
def update_position():
    """
    JS에서 보낸 좌표와 방향 데이터를 받아 MySQL에 저장합니다.
    데이터 형식 예시: {"x": 55, "y": 50, "direction": "right"}
    """
    data = request.get_json()
    
    if not data:
        return jsonify({"status": "error", "message": "데이터가 없습니다."}), 400

    x = data.get('x')
    y = data.get('y')
    direction = data.get('direction')

    # MySQL 데이터베이스에 접속 및 저장
    try:
        connection = pymysql.connect(**db_config)
        with connection.cursor() as cursor:
            # 쿼리 실행: robot_logs 테이블에 좌표와 방향 기록
            sql = "INSERT INTO robot_logs (x, y, direction) VALUES (%s, %s, %s)"
            cursor.execute(sql, (x, y, direction))
        
        connection.commit() # 변경사항 반영
        connection.close()  # 연결 종료
        
        print(f"[DB 저장 완료] x: {x}, y: {y}, 방향: {direction}")
        return jsonify({"status": "success", "received": data})

    except pymysql.MySQLError as e:
        print(f"[DB 에러] {e}")
        return jsonify({"status": "error", "message": "데이터베이스 저장 실패"}), 500

if __name__ == '__main__':
    # 0.0.0.0으로 설정하면 같은 네트워크의 다른 기기에서도 접속 가능합니다.
    app.run(host='0.0.0.0', port=5000, debug=True)