document.addEventListener('DOMContentLoaded', () => {
    const robot = document.getElementById('robot');
    const buttons = document.querySelectorAll('.ctrl-btn');
    
    let posX = 50;
    let posY = 50;
    const step = 5;

    buttons.forEach(button => {
        button.addEventListener('click', () => {
            // 1. 버튼 색상 변경
            buttons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            // 3. 방향 계산
            const direction = button.getAttribute('data-dir');
            if (direction === 'up') posY -= step;
            else if (direction === 'down') posY += step;
            else if (direction === 'left') posX -= step;
            else if (direction === 'right') posX += step;

            // 경계 제한
            posX = Math.max(5, Math.min(95, posX));
            posY = Math.max(5, Math.min(95, posY));

            // 화면 반영
            robot.style.left = `${posX}%`;
            robot.style.top = `${posY}%`;

            // --- 추가된 API 연동 부분 ---
            sendPositionToServer(posX, posY, direction);
        });
    });

    // 서버로 데이터를 보내는 함수
    function sendPositionToServer(x, y, dir) {
        fetch('/update_position', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ x: x, y: y, direction: dir }),
        })
        .then(response => response.json())
        .then(data => {
            console.log('서버 응답:', data);
        })
        .catch((error) => {
            console.error('Error:', error);
        });
    }
});